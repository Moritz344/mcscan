# mcstatus-cli
A CLI application to fetch data from your favourite minecraft server.

# API
This project uses the [mcstatus API](https://mcstatus.io/docs) to retrieve real-time data from Minecraft servers.

# Author
- Moritz344


